<?php 

return [
    '/login' => 'site/login',
    '/register' => 'site/register',
    'users' => 'admin/default/users'
];

?>