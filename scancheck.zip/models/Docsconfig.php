<?php 

namespace app\models;

use yii\db\ActiveRecord;

class Docsconfig extends ActiveRecord{

}